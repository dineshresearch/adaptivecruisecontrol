void delay_fv(unsigned int x,int y);
void delay_ms(int count);
void Delay(unsigned char j);
void Delay_Small(unsigned char j);
