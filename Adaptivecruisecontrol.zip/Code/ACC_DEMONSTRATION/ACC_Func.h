#ifndef __ACC_FUNC_H
#define __ACC_FUNC_H

void Switch_Operation(void);
void Buzzer_Operation(void);
void ACC_Mode_Chng_Reset_Settings(void);
void ACC_Off_Action(void);
void ACC_Run_Mode_Update(void);
void ACC_Set_Val_Update(void);

#endif
